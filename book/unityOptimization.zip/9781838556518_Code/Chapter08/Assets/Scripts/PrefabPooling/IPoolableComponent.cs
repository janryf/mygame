﻿public interface IPoolableComponent {
    void Spawned();
    void Despawned();
}