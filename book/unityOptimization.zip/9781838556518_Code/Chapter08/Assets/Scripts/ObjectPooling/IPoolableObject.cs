﻿public interface IPoolableObject {
    void New();
    void Respawn();
}