﻿public class Message {
    public string type;
    public Message() { type = this.GetType().Name; }
}