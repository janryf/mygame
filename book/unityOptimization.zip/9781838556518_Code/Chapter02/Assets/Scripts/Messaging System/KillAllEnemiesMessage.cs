﻿public class KillAllEnemiesMessage : Message {

}