﻿public class CreateEnemyMessage : Message {
	
}
