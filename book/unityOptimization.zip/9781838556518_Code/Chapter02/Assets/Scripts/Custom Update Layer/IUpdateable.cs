﻿public interface IUpdateable {
    void OnUpdate(float dt);
}